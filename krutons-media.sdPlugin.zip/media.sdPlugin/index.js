const WebSocket = require('ws');
const zlib = require('zlib');
const fs   = require('fs');
const os   = require('os');
const path = require('path');
const { execSync, spawn } = require('child_process');

const args = process.argv.slice(2);
const port = args[args.indexOf('-port') + 1];
const uuid = args[args.indexOf('-pluginUUID') + 1];
const socket = new WebSocket('ws://localhost:' + port);

let instances = {};
let isMuted = false;

socket.on('open', () => {
  socket.send(JSON.stringify({ event: 'registerPlugin', uuid }));
});

socket.on('message', (data) => {
  const msg = JSON.parse(data);
  if (msg.event === 'willAppear' || msg.event === 'didReceiveSettings') {
    const s = msg.payload.settings || {};
    instances[msg.context] = {
      action: msg.action,
      color:  s.color  || defaultColor(msg.action),
      label:  s.label  || defaultLabel(msg.action),
    };
  }
  if (msg.event === 'willDisappear') delete instances[msg.context];
  if (msg.event === 'keyDown') handleKeyDown(msg.action);
});

// ── Key sender ────────────────────────────────────────────────────────────────
// Compile a tiny C# exe once using the .NET Framework compiler that ships
// with every Windows install. After that each keypress is ~5ms.

const tmpDir  = os.tmpdir();
const exePath = path.join(tmpDir, 'kruton_key.exe');
const csPath  = path.join(tmpDir, 'kruton_key.cs');

const csSrc = `
using System;
using System.Runtime.InteropServices;
using System.Threading;
class K {
    [DllImport("user32.dll")]
    static extern void keybd_event(byte vk, byte scan, uint flags, int extra);
    static void Main(string[] a) {
        if (a.Length < 1) return;
        byte vk = (byte)int.Parse(a[0]);
        keybd_event(vk, 0, 0, 0);
        Thread.Sleep(20);
        keybd_event(vk, 0, 2, 0);
    }
}`;

function buildKeyExe() {
  const candidates = [
    'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe',
    'C:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe',
  ];
  const csc = candidates.find(p => fs.existsSync(p));
  if (!csc) return false;
  try {
    fs.writeFileSync(csPath, csSrc);
    execSync(`"${csc}" /nologo /out:"${exePath}" "${csPath}"`, { timeout: 10000, windowsHide: true });
    return true;
  } catch(e) {
    console.error('[media] compile failed:', e.message);
    return false;
  }
}

let useExe = fs.existsSync(exePath) || buildKeyExe();

function sendKey(vk) {
  if (useExe) {
    // Fire-and-forget — spawn detached, don't wait, never blocks
    const child = spawn(exePath, [String(vk)], {
      detached: true,
      stdio: 'ignore',
      windowsHide: true,
    });
    child.unref();
  } else {
    // Fallback: wscript with a tiny VBScript — faster than PS to start
    const vbs = `Set o=CreateObject("WScript.Shell"):o.SendKeys""`;
    // Last resort: just try the WshShell SendKeys for media keys
    const psScript = path.join(tmpDir, 'kruton_key_fb.ps1');
    if (!fs.existsSync(psScript)) {
      fs.writeFileSync(psScript, `param([int]$vk)
Add-Type -TypeDefinition @"
using System;using System.Runtime.InteropServices;
public class K{[DllImport("user32.dll")]public static extern void keybd_event(byte v,byte s,uint f,int e);}
"@
[K]::keybd_event($vk,0,0,0);Start-Sleep -Milliseconds 20;[K]::keybd_event($vk,0,2,0)`);
    }
    const child = spawn('powershell', [
      '-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',
      '-File', psScript, '-vk', String(vk)
    ], { detached: true, stdio: 'ignore', windowsHide: true });
    child.unref();
  }
}

function handleKeyDown(action) {
  switch(action) {
    case 'com.kruton.media.playpause': sendKey(0xB3); break;
    case 'com.kruton.media.next':      sendKey(0xB0); break;
    case 'com.kruton.media.prev':      sendKey(0xB1); break;
    case 'com.kruton.media.stop':      sendKey(0xB2); break;
    case 'com.kruton.media.volup':     sendKey(0xAF); break;
    case 'com.kruton.media.voldown':   sendKey(0xAE); break;
    case 'com.kruton.media.mute':
      sendKey(0xAD);
      isMuted = !isMuted;
      break;
  }
}

// ── Defaults ──────────────────────────────────────────────────────────────────
function defaultColor(action) {
  const map = {
    'com.kruton.media.playpause': '#00ffcc',
    'com.kruton.media.next':      '#7b61ff',
    'com.kruton.media.prev':      '#7b61ff',
    'com.kruton.media.stop':      '#ff4444',
    'com.kruton.media.volup':     '#ff9500',
    'com.kruton.media.voldown':   '#ff9500',
    'com.kruton.media.mute':      '#ff9500',
  };
  return map[action] || '#ffffff';
}

function defaultLabel(action) {
  const map = {
    'com.kruton.media.playpause': 'PLAY',
    'com.kruton.media.next':      'NEXT',
    'com.kruton.media.prev':      'PREV',
    'com.kruton.media.stop':      'STOP',
    'com.kruton.media.volup':     'VOL+',
    'com.kruton.media.voldown':   'VOL-',
    'com.kruton.media.mute':      'MUTE',
  };
  return map[action] || '';
}

// ── PNG encoder ───────────────────────────────────────────────────────────────
function makePng(pixels, W, H) {
  const rows = [];
  for (let y = 0; y < H; y++) {
    const row = Buffer.alloc(1 + W * 4);
    row[0] = 0;
    for (let x = 0; x < W; x++) {
      const p = pixels[y*W+x];
      row[1+x*4]   = (p>>>24)&0xff;
      row[1+x*4+1] = (p>>>16)&0xff;
      row[1+x*4+2] = (p>>>8) &0xff;
      row[1+x*4+3] =  p      &0xff;
    }
    rows.push(row);
  }
  const raw = Buffer.concat(rows);
  const idat = zlib.deflateSync(raw, { level: 1 });
  function crc(b){let c=0xffffffff;for(const x of b){c^=x;for(let i=0;i<8;i++)c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1);}return(c^0xffffffff)>>>0;}
  function chunk(t,d){const tb=Buffer.from(t),lb=Buffer.alloc(4),kb=Buffer.alloc(4);lb.writeUInt32BE(d.length);kb.writeUInt32BE(crc(Buffer.concat([tb,d])));return Buffer.concat([lb,tb,d,kb]);}
  const ihdr=Buffer.alloc(13);ihdr.writeUInt32BE(W,0);ihdr.writeUInt32BE(H,4);ihdr[8]=8;ihdr[9]=6;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ihdr),chunk('IDAT',idat),chunk('IEND',Buffer.alloc(0))]);
}

const W = 144, H = 144;

function blend(px, x, y, r, g, b, a) {
  if(x<0||x>=W||y<0||y>=H)return;
  const i=y*W+x,sa=a/255,da=(px[i]&0xff)/255,oa=sa+da*(1-sa);
  if(oa<0.001)return;
  const pr=(px[i]>>>24)&0xff,pg=(px[i]>>>16)&0xff,pb=(px[i]>>>8)&0xff;
  px[i]=(Math.min(255,Math.round((r*sa+pr*da*(1-sa))/oa))<<24)|
        (Math.min(255,Math.round((g*sa+pg*da*(1-sa))/oa))<<16)|
        (Math.min(255,Math.round((b*sa+pb*da*(1-sa))/oa))<<8)|
        Math.round(oa*255);
}

function hexRgb(h){return[parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)];}

const FONT = {
  'A':['01110','10001','10001','11111','10001','10001','10001'],
  'B':['11110','10001','10001','11110','10001','10001','11110'],
  'C':['01110','10001','10000','10000','10000','10001','01110'],
  'D':['11110','10001','10001','10001','10001','10001','11110'],
  'E':['11111','10000','10000','11110','10000','10000','11111'],
  'G':['01110','10001','10000','10111','10001','10001','01111'],
  'H':['10001','10001','10001','11111','10001','10001','10001'],
  'I':['01110','00100','00100','00100','00100','00100','01110'],
  'K':['10001','10010','10100','11000','10100','10010','10001'],
  'L':['10000','10000','10000','10000','10000','10000','11111'],
  'M':['10001','11011','10101','10001','10001','10001','10001'],
  'N':['10001','11001','10101','10011','10001','10001','10001'],
  'O':['01110','10001','10001','10001','10001','10001','01110'],
  'P':['11110','10001','10001','11110','10000','10000','10000'],
  'R':['11110','10001','10001','11110','10100','10010','10001'],
  'S':['01110','10001','10000','01110','00001','10001','01110'],
  'T':['11111','00100','00100','00100','00100','00100','00100'],
  'U':['10001','10001','10001','10001','10001','10001','01110'],
  'V':['10001','10001','10001','10001','10001','01010','00100'],
  'W':['10001','10001','10001','10101','10101','11011','10001'],
  'X':['10001','10001','01010','00100','01010','10001','10001'],
  'Y':['10001','10001','01010','00100','00100','00100','00100'],
  '0':['01110','10001','10001','10001','10001','10001','01110'],
  '1':['00100','01100','00100','00100','00100','00100','01110'],
  '2':['01110','10001','00001','00110','01000','10000','11111'],
  '3':['11110','00001','00001','01110','00001','00001','11110'],
  '4':['00010','00110','01010','10010','11111','00010','00010'],
  '5':['11111','10000','11110','00001','00001','10001','01110'],
  '6':['00110','01000','10000','11110','10001','10001','01110'],
  '7':['11111','00001','00010','00100','01000','01000','01000'],
  '8':['01110','10001','10001','01110','10001','10001','01110'],
  '9':['01110','10001','10001','01111','00001','00010','01100'],
  '+':['00000','00100','00100','11111','00100','00100','00000'],
  '-':['00000','00000','00000','11111','00000','00000','00000'],
  ' ':['00000','00000','00000','00000','00000','00000','00000'],
};

function drawText(px, text, cx, y, scale, r, g, b, a=255) {
  const chars = text.toUpperCase().split('');
  const cw = 5*scale + scale;
  const totalW = chars.length*cw - scale;
  let x = Math.round(cx - totalW/2);
  for (const ch of chars) {
    const bmp = FONT[ch];
    if (bmp) for (let row=0; row<7; row++) for (let col=0; col<5; col++)
      if (bmp[row][col]==='1') for (let sy=0; sy<scale; sy++) for (let sx=0; sx<scale; sx++)
        blend(px, x+col*scale+sx, y+row*scale+sy, r, g, b, a);
    x += cw;
  }
}

function fillTriangle(px, x0,y0, x1,y1, x2,y2, r,g,b,a=255) {
  const minX=Math.max(0,Math.min(x0,x1,x2)), maxX=Math.min(W-1,Math.max(x0,x1,x2));
  const minY=Math.max(0,Math.min(y0,y1,y2)), maxY=Math.min(H-1,Math.max(y0,y1,y2));
  function sign(ax,ay,bx,by,cx2,cy2){return(ax-cx2)*(by-cy2)-(bx-cx2)*(ay-cy2);}
  for(let y=minY;y<=maxY;y++) for(let x=minX;x<=maxX;x++){
    const d1=sign(x,y,x0,y0,x1,y1),d2=sign(x,y,x1,y1,x2,y2),d3=sign(x,y,x2,y2,x0,y0);
    if(!((d1<0||d2<0||d3<0)&&(d1>0||d2>0||d3>0))) blend(px,x,y,r,g,b,a);
  }
}

function fillRect(px,x,y,w,h,r,g,b,a=255){
  for(let dy=0;dy<h;dy++) for(let dx=0;dx<w;dx++) blend(px,x+dx,y+dy,r,g,b,a);
}

function fillRoundRect(px,x,y,w,h,rad,r,g,b,a=255){
  for(let py=y;py<y+h;py++) for(let px2=x;px2<x+w;px2++){
    const cx2=Math.max(x+rad,Math.min(x+w-rad-1,px2)), cy2=Math.max(y+rad,Math.min(y+h-rad-1,py));
    const cov=Math.max(0,Math.min(1,rad-Math.sqrt((px2-cx2)**2+(py-cy2)**2)+0.5));
    if(cov>0) blend(px,px2,py,r,g,b,Math.round(a*cov));
  }
}

function fillCircle(px,cx,cy,cr,r,g,b,a=255){
  for(let y=cy-cr-1;y<=cy+cr+1;y++) for(let x=cx-cr-1;x<=cx+cr+1;x++){
    const cov=Math.max(0,Math.min(1,cr-Math.sqrt((x-cx)**2+(y-cy)**2)+0.5));
    if(cov>0) blend(px,x,y,r,g,b,Math.round(a*cov));
  }
}

function makeBg(px, color) {
  const [r,g,b] = hexRgb(color);
  for(let i=0;i<W*H;i++) px[i]=(10<<24)|(10<<16)|(12<<8)|255;
  const cr=48;
  for(let y=0;y<H;y++) for(let x=0;x<W;x++){
    const d=Math.sqrt((x-W/2)**2+(y-H/2-8)**2)/cr;
    blend(px,x,y,r,g,b,Math.round(Math.max(0,1-d*d)*30));
  }
}

function drawLabel(px, label, color, override) {
  const [r,g,b] = hexRgb(color);
  drawText(px, override || label, W/2, H-20, 2, r, g, b);
}

function pxToDataUrl(px) {
  return 'data:image/png;base64,' + makePng(px, W, H).toString('base64');
}

// ── Button renderers ──────────────────────────────────────────────────────────
function renderPlayPause(color, label) {
  const px = new Int32Array(W*H); makeBg(px, color);
  const [r,g,b]=hexRgb(color), cx=W/2, cy=H/2-8;
  fillRect(px,cx-18,cy-20,12,38,r,g,b);
  fillRect(px,cx+6, cy-20,12,38,r,g,b);
  fillTriangle(px,cx-4,cy-12,cx-4,cy+12,cx+14,cy,r,g,b,160);
  drawLabel(px,label,color); return px;
}
function renderNext(color, label) {
  const px = new Int32Array(W*H); makeBg(px, color);
  const [r,g,b]=hexRgb(color), cx=W/2, cy=H/2-8;
  fillTriangle(px,cx-22,cy-18,cx-22,cy+18,cx+2,cy,r,g,b);
  fillTriangle(px,cx+2,cy-18,cx+2,cy+18,cx+22,cy,r,g,b);
  fillRect(px,cx+22,cy-18,8,36,r,g,b);
  drawLabel(px,label,color); return px;
}
function renderPrev(color, label) {
  const px = new Int32Array(W*H); makeBg(px, color);
  const [r,g,b]=hexRgb(color), cx=W/2, cy=H/2-8;
  fillTriangle(px,cx+22,cy-18,cx+22,cy+18,cx-2,cy,r,g,b);
  fillTriangle(px,cx-2,cy-18,cx-2,cy+18,cx-22,cy,r,g,b);
  fillRect(px,cx-30,cy-18,8,36,r,g,b);
  drawLabel(px,label,color); return px;
}
function renderStop(color, label) {
  const px = new Int32Array(W*H); makeBg(px, color);
  const [r,g,b]=hexRgb(color), cx=W/2, cy=H/2-8;
  fillRoundRect(px,cx-22,cy-22,44,44,6,r,g,b);
  drawLabel(px,label,color); return px;
}
function renderVolUp(color, label) {
  const px = new Int32Array(W*H); makeBg(px, color);
  const [r,g,b]=hexRgb(color), cx=W/2, cy=H/2-8;
  fillRect(px,cx-22,cy-8,12,20,r,g,b);
  fillTriangle(px,cx-10,cy-18,cx-10,cy+18,cx+8,cy,r,g,b);
  for(let i=-8;i<=8;i++) blend(px,cx+20,cy+i,r,g,b,200);
  for(let i=-14;i<=14;i++) blend(px,cx+26,cy+i,r,g,b,160);
  fillRect(px,cx+32,cy-10,4,20,r,g,b);
  fillRect(px,cx+24,cy-2,20,4,r,g,b);
  drawLabel(px,label,color); return px;
}
function renderVolDown(color, label) {
  const px = new Int32Array(W*H); makeBg(px, color);
  const [r,g,b]=hexRgb(color), cx=W/2, cy=H/2-8;
  fillRect(px,cx-22,cy-8,12,20,r,g,b);
  fillTriangle(px,cx-10,cy-18,cx-10,cy+18,cx+8,cy,r,g,b);
  for(let i=-8;i<=8;i++) blend(px,cx+20,cy+i,r,g,b,200);
  fillRect(px,cx+26,cy-2,20,4,r,g,b);
  drawLabel(px,label,color); return px;
}
function renderMute(color, label, muted) {
  const activeColor = muted ? '#ff4444' : color;
  const px = new Int32Array(W*H); makeBg(px, activeColor);
  const [r,g,b]=hexRgb(activeColor), cx=W/2, cy=H/2-8;
  fillRect(px,cx-22,cy-8,12,20,r,g,b);
  fillTriangle(px,cx-10,cy-18,cx-10,cy+18,cx+8,cy,r,g,b);
  if(muted){
    for(let i=-14;i<=14;i++){
      for(let t=-1;t<=1;t++){
        blend(px,cx+16+i+t,cy-14+i,r,g,b,220);
        blend(px,cx+16+i+t,cy+14-i,r,g,b,220);
      }
    }
  } else {
    for(let i=-8;i<=8;i++) blend(px,cx+20,cy+i,r,g,b,200);
    for(let i=-14;i<=14;i++) blend(px,cx+26,cy+i,r,g,b,160);
  }
  drawLabel(px,label,activeColor,muted?'MUTED':null); return px;
}

// ── Update loop ───────────────────────────────────────────────────────────────
// Buttons are static — only re-render when mute state changes
let lastMuted = null;
let rendered = {};

function update() {
  const muteChanged = isMuted !== lastMuted;
  if (muteChanged) lastMuted = isMuted;

  for (const [ctx, cfg] of Object.entries(instances)) {
    // Only re-render if needed
    const isMuteBtn = cfg.action === 'com.kruton.media.mute';
    if (rendered[ctx] && !muteChanged && !isMuteBtn) continue;

    let px;
    switch(cfg.action) {
      case 'com.kruton.media.playpause': px = renderPlayPause(cfg.color, cfg.label); break;
      case 'com.kruton.media.next':      px = renderNext(cfg.color, cfg.label); break;
      case 'com.kruton.media.prev':      px = renderPrev(cfg.color, cfg.label); break;
      case 'com.kruton.media.stop':      px = renderStop(cfg.color, cfg.label); break;
      case 'com.kruton.media.volup':     px = renderVolUp(cfg.color, cfg.label); break;
      case 'com.kruton.media.voldown':   px = renderVolDown(cfg.color, cfg.label); break;
      case 'com.kruton.media.mute':      px = renderMute(cfg.color, cfg.label, isMuted); break;
      default: continue;
    }
    socket.send(JSON.stringify({
      event: 'setImage', context: ctx,
      payload: { image: pxToDataUrl(px) }
    }));
    rendered[ctx] = true;
  }
}

// Clear render cache when settings change so buttons redraw
socket.on('message', () => { rendered = {}; });

setInterval(update, 500);
